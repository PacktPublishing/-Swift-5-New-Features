//ViewController.swift
//WhatIsNewInSwift5 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let scores = 0...100
        
        let encoder = JSONEncoder()
        let encodedData = try! encoder.encode(scores)
        
        let decoder = JSONDecoder()
        let decodedData = try! decoder.decode(ClosedRange<Int>.self, from: encodedData)
        
        print(decodedData)
        
    }
    
    //A lightweight collection of key-value pairs.
    //key value pair is ordered
    //slow compared to dictionary
    //allows duplicate
    func dictionaryLiteral(){
        
        let dictionary = ["name": "Dee Odus", "age": 37, "height": 185.0] as [String : Any]
        print(dictionary.first)
        
        let dictionary2: DictionaryLiteral = ["name": "Dee Odus", "age": 37, "height": 185.0, "name": "Dee"] as KeyValuePairs<String, Any>
        
        print(dictionary2.first, dictionary2.last)
    }
    
    func compactMapValues(){
        
        let scores = ["Dee": "10", "James": "5", "Mary": "", "Nori": "ten"]
        
         //converts the dictionary value to int
         //map values return a new dictionary containing the key with the value transformed based on the closure.
         
         //Int.init simply takes a string and returns and int or a nil if that value cannot be converted to an integer
        
        //USING MAP VALUES
         let transformedScores = scores.mapValues(Int.init)
         
         //filter out the non nil
         let nonNilScores = transformedScores.filter { $0.value != nil }
         
         //get only values that unwraps
         let finalScores = nonNilScores.mapValues { $0! }
         
         print(finalScores)
        
        
        //returns a new dictionary containing only the key value pairs that have non nil, as a result of transformation by the given closure
        
        //USING COMPACT MAP VALUES
        let dict = scores.compactMapValues(Int.init)
        print(dict)
    }

}

