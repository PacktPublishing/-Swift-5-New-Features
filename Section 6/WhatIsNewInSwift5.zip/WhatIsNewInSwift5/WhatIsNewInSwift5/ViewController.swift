//ViewController.swift
//WhatIsNewInSwift5 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let string = "This is a string"
        let _ = string.endIndex.utf16Offset(in: string)
        
        let array = [1, 3, 5, 7, 9, 9, 9]
        let index = array.firstIndex(of: 9)
        
        print(index ?? 0)
    }
    
}
