//ViewController.swift
//WhatIsNewInSwift5 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let string = "This is a string"
        let _ = string.endIndex.utf16Offset(in: string)
    }
    
}

func compilationChanges(){
    
    let number = 10
    var isOdd = false
    
    //Swift 4.2 did not support less than
    
    #if !swift(>=5)
        isOdd = number % 2 == 0
    #else
        isOdd = number.isMultiple(of: 2)
    #endif
    
    
    //Swift 5 supports less than
    #if swift(<5)
        isOdd = number % 2 == 0
    #else
        isOdd = number.isMultiple(of: 2)
    #endif
    
    print(isOdd)
}
