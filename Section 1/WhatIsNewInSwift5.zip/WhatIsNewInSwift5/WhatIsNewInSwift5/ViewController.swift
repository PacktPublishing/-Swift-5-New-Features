//ViewController.swift
//WhatIsNewInSwift5 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        checkUnicodeScalar(string: "stable121AWS@")
    }
    
    func checkUnicodeScalar(string: String){
        
        for scalar in string.unicodeScalars{
            
            if scalar.properties.isUppercase{
                print("\(scalar) is a CAPITAL letter")
            }else if scalar.properties.isLowercase{
                
                print("\(scalar) is a LOWER letter")
            }else if scalar.properties.isHexDigit{
                
                print("\(scalar) is a NUMBER")
            }
            
            /*let scalarValue = scalar.value
            
            if (48...57).contains(scalarValue){
                
                print("\(scalar) is a number")
            }else if (65...90).contains(scalarValue){
                
                print("\(scalar) is a CAPITAL letter")
            }else if (97...122).contains(scalarValue){
                
                print("\(scalar) is a LOWER letter")
            }*/
        }
    }
    
    /*func characterIsNumber(string: String){
        
        let characters = Array(string)
        
        for character in characters{
            
            if character.isNumber{
                print("\(character) is a number")
            }else{
                print("\(character) is NOT a number")
            }
            
            /*let stringCharacter = String(character)
            let characterInt = Int(stringCharacter)
            
            if characterInt != nil{
                
                print("\(character) is a number")
            }else{
                print("\(character) is NOT a number")
            }*/
        }
    }*/

    /*
    func checkMultiple(first:Int, second: Int) -> Bool{
        
        if second.isMultiple(of: first){
            return true
        }
        
        return false
    }*/

}

