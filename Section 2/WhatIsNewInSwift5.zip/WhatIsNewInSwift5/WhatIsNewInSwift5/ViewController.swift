//ViewController.swift
//WhatIsNewInSwift5 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

struct Person{
    
    var name: String
    var age: Int
    var height: Float
}

extension String.StringInterpolation{
    
    mutating func appendInterpolation(_ person: Person){
        
        print("My name is \(person.name). I am \(person.age). I am \(person.height)cm tall")
    }
    
    mutating func appendInterpolation(_ name: String, _ age: Int){
        
        print("My name is \(name) and I am \(age)")
    }
}

extension String{
    
    enum EmptyError: Error{
        
        case emptyString
    }
    
    func characters() throws -> String{
        
        if self.isEmpty{
            
            throw EmptyError.emptyString
        }
        
        return "\(self.count)"
    }
}

enum RegistrationError{
    
    case username
    case email
    case password
    case name
    case age //age must be at least 18
}

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let time = 9
        let string = #"I asked "when am I going to see you next?", he said "see you next week at \#(time)", and I replied "good night""#
        print(string)
        
        let deeodus = Person.init(name: "Dee Odus", age: 38, height: 185)
        print("\(deeodus.name, deeodus.age)")
        
        let name = Optional.some("deeodus")
        let characters = try? name?.characters()
        
        if let characters = characters{
            print(characters)
        }
        
        showError(error: .username)
        showError(error: .email)
        showError(error: .password)
        showError(error: .name)
        showError(error: .age)
    }
    
    func showError(error: RegistrationError){
        
        switch error{
            
        case .username:
            print("username must be lower cases")
            
        case .email:
            print("email format is not correct")
            
        case .password:
            print("password must be at least 8 characters")
            
        case .name:
            <#code#>
        case .age:
            <#code#>
        @unknown default:
            print("all details are required")
        }
    }
    
}

