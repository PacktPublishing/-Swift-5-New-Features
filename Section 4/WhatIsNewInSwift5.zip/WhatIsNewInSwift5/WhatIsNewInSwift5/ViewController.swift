//ViewController.swift
//WhatIsNewInSwift5 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

enum CustomError: Error {
    case networkIssue
}

struct Person{
    
    let name: String
    let firstname: String
}

@dynamicCallable

struct Callable {
    func dynamicallyCall(withArguments: [Int]) {}
    func dynamicallyCall(withKeywordArguments: [String : Int]) {}
}

@dynamicCallable
struct Emergency {
    
    func dynamicallyCall(withArguments emergencyNumber: [Int]){
        
        if emergencyNumber == [9,9,9]{
            
            print("You have dialled the emergency number")
        }else{
            
            print("Incorrect number")
        }
    }
    
    func dynamicallyCall(withKeywordArguments numbers: KeyValuePairs<String, Int>){
        
        let first = numbers.first?.value
        let last = numbers.last?.value
        
        if first == 9 && last == 9{
            print("You have dialled the emergency number")
        }else{
            print("Incorrect number")
        }
        
    }
}


class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let emergency = Emergency()
        //emergency.dynamicallyCall(withKeywordArguments: ["first": 9, "second": 0, "third": 9, "fourth": 5])
        emergency(first: 9, second: 0, third: 9)
    }
    
    
    func usingResultType(){
        
        countValue(value: nil) { (result) in
            
            switch result{
                
            case .success(let value):
                print(value)
                
            case .failure(let error):
                print("error occured", error.localizedDescription)
            }
        }
        
        
        countValue(value: "my name is dee") { (value, error) in
            
            //possible situations
            if error != nil && value == nil{
                
                print("error not nil, value is nil")
            }
            
            if error == nil && value != nil{
                
                print("error is nil, value is not nil")
            }
            
            //impossible situations
            if error == nil && value == nil{
                
                print("error and value are nil")
            }
            
            if error != nil && value != nil{
                
                print("both values and errors are availble")
            }
        }
    }
    
    func usingKeyPath(){
        
        var dee = Person.init(name: "Dee Odus", firstname: "Dee")
        
        let namePath = \Person.firstname
        //set label
        print(dee[keyPath: namePath])
        
        //set another label
        print(dee[keyPath: namePath])
        
        //set title
        print(dee[keyPath: namePath])
        
        dee[keyPath: \.self] = Person.init(name: "James Brown", firstname: "James")
        
        //set label
        print(dee[keyPath: namePath])
        
        //set another label
        print(dee[keyPath: namePath])
        
        //set title
        print(dee[keyPath: namePath])
    }
    
    func countValue(value: String?, completionHandler: @escaping (Int?, CustomError?) -> Void) {
        
        if value == nil{
            
            completionHandler(nil, .networkIssue)
            return
        }
        
        completionHandler(value?.count, nil)
    }
    
    func countValue(value: String?, completionHandler: @escaping (Result<Int, Error>) -> Void)  {
        
        if value == nil{
            
            completionHandler(.failure(NSError.init(domain: "", code: 200)))
            return
        }
        
        completionHandler(.success(value!.count))
    }
    
}

